
import streamlit as st
st.set_page_config(page_title="Application Form", layout="wide")
st.title("Licensed Surveyor Application Form")
st.write("This is a sample application form page.")
