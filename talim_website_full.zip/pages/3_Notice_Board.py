
import streamlit as st
st.set_page_config(page_title="Notice Board", layout="wide")
st.title("Notice Board")
st.write("This is a sample notice board page.")
