
import streamlit as st
st.set_page_config(page_title="Gallery", layout="wide")
st.title("Gallery")
st.write("This is a sample gallery page.")
