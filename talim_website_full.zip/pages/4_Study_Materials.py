
import streamlit as st
st.set_page_config(page_title="Study Materials", layout="wide")
st.title("Study Materials")
st.write("This is a sample study materials page.")
